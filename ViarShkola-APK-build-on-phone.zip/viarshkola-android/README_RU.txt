ВиарШкола — проект Android-приложения

Это исходный проект-обёртка Android WebView для вашего HTML-сайта. В текущей среде нет Android SDK/Gradle, поэтому готовый APK здесь скомпилировать не удалось.

Как получить APK:
1. Установите Android Studio на компьютер.
2. Откройте в Android Studio папку ViarShkola (папку проекта из архива).
3. Дождитесь Gradle Sync и установите предложенные Android SDK компоненты.
4. Выберите Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK появится в app/build/outputs/apk/debug/app-debug.apk.

Приложение загружает app/src/main/assets/index.html локально, интернет для отображения страницы не нужен.
Примечание: сайт сохраняет оценки локально в браузерном хранилище WebView на устройстве.
